// Copyright 2013 Howling Moon Software. All rights reserved.
// See http://chipmunk2d.net/legal.php for more information.

//#define ChipmunkGetObject(s) s->data
//#define ChipmunkGetData(s) [s->data data]
